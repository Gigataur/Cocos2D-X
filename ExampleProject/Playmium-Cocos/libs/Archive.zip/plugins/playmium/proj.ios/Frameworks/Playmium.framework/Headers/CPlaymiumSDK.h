//
//  CPlaymiumSDK.h
//  PlaymiumSDK
//
//  Created by Eric Dalrymple on 2015/05/03.
//  Copyright (c) 2015 Gigataur. All rights reserved.
//

#ifndef __PlaymiumSDK__CPlaymiumSDK__
#define __PlaymiumSDK__CPlaymiumSDK__

#include <cstddef>

#include "./PlaymiumDefines.h"

class PlaymiumSDKCore;

class CPlaymiumSDK
{
public:
  /**
   * Returns a human readable string describing the specified error.
   * @param error an Error
   */
  static const char* getStringForError( const Playmium::Error& error );

  /**
   * Pauses the current Playmium session. This method should be called whenever
   * the application enters the background. This method has the same effect as
   * the method inside PlaymiumSDK with the same name and only one of them needs
   * to be called. The method is ineffective unless the current session is started
   * when called.
   */
  static void pauseSession();
  
  /**
   * Resumes the current Playmium session. This method should be called whenever
   * the application enters the foreground. This method has the same effect as
   * the method inside PlaymiumSDK with the same name and only one of them needs
   * to be called. The method is ineffective unless the currentsession is paused
   * when called.
   */
  static void resumeSession();
  
  /**
   * Starts a new Playmium session. This method should be called when the application
   * launches. This method has the same effect as the method of the same name inside
   * PlaymiumSDK and only one of them needs to be called.
   * @param debug 'true' to enable debug mode, 'false' otherwise
   * @param error an Error reference used as an output parameter in order to allow the caller to handle errors
   */
  static void startSession( bool debug, Playmium::Error* error = NULL );
  
  /**
   * Starts a new Playmium session. This method should be called when the application
   * launches. This method has the same effect as the method of the same name inside
   * PlaymiumSDK and only one of them needs to be called.
   * @param debug           'true' to enable debug mode, 'false' otherwise
   * @param firstAppLaunch  'true' if this is the first time the application was launched, 'false' otherwise
   * @param error           an Error reference used as an output parameter in order to allow the caller to handle errors
   */
  static void startSession( bool debug, bool firstAppLaunch, Playmium::Error* error = NULL );
  
  /**
   * Stops the current Playmium session. This method be called when the application
   * shuts down. This method has the same effect as the method of the same name inside
   * PlaymiumSDK and only one of them needs to be called.
   */
  static void stopSession();
  
  /**
   * Opens the End User License Agreement using the device's internet browser. Calling
   * this function will force the application to the background.
   */
  static bool showEULA();
  
  /**
   * Opens the Privacy Policy using the device's internet browser. Calling
   * this function will force the application to the background.
   */
  static bool showPrivacyPolicy();
  
  /**
   * Stores the directory passed in as the place to find and extract the Keystone files used with configuration and authentication
   */
  static void sendKeystoneFilePath(const char *directory);
  
//  /**
//   * Opens the  using the device's internet browser. Calling
//   * this function will force the application to the background.
//   */
//  static void showUserFeedbackForm( Playmium::UserFeedbackType feedbackType );
};

#endif /* defined(__PlaymiumSDK__CPlaymiumSDK__) */
